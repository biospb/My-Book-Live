7.3.0-mbl-73r1-slim: mainline Linux 7.3 port for APM82181 / WD My Book Live.
Series, config and measurements: see the 7.3 README in the repository
(kernel/patches/7.3/README.md). Slim build: NFSD/F2FS/overlay/MD/DM and
other unused subsystems are modules; read-ahead capped at 128 KiB (patch 0017).
Boot argument used in testing: libata.force=noncq rng_core.default_quality=700.
Install into the multiboot test slot (mbl-boot test); swap must already be
16K-page formatted (mkswap /dev/sda3 after switching page sizes).
