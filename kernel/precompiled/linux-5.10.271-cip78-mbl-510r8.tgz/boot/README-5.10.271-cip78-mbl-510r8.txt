Linux 5.10.271-cip78-mbl-510r8 (candidate, November 2026)
Source: CIP v5.10.271-cip78 + MBL patches 0001-0023 (kernel/patches/5.10.271-cip78).
The 4.19 series ported to CIP SLTS 5.10. 16K pages; PERF_EVENTS enabled.
DTB is the tested board DTB (zero local-mac-address; no personal bootargs).
Use libata.force=noncq and panic=10; install into the multiboot test slot first.
Results (fixed-placement SMB bench): 79.0 / 101.8 MiB/s, free CPU on read 26 %.
