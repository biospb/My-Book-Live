Linux 6.1.189-cip61-mbl-61r3 (port, November 2026)
Source: CIP v6.1.189-cip61 + MBL patches 0001-0008 (kernel/patches/6.1.189-cip61).
The 5.10 series ported to CIP SLTS 6.1. 16K pages; PERF_EVENTS enabled.
DTB is the tested board DTB (zero local-mac-address; no personal bootargs).
Use libata.force=noncq and panic=10; install into the multiboot test slot first.
Results (fixed-placement SMB bench): 79.2 / 101.6 MiB/s, free CPU on read 23 %.
