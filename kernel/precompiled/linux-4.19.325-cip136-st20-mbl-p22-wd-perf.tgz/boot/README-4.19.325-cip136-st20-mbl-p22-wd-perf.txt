Linux 4.19.325-cip136-st20-mbl-p22-wd-perf
Source: CIP v4.19.325-cip136 + MBL patches 0001-0022.
Build base through 0021: 67fd5fc76db9af1bb4610d27893a7e48c04e5510.
16K pages; software hang recovery; PERF_EVENTS enabled; no mbl_copy_diag code.
Patch 0022 optimizes only memcpy_from_page using the existing bounded PPC loop.
DTB is the exact tested board DTB (zero local-mac-address; no personal bootargs).
Use libata.force=noncq and panic=10; Samba splice is installed separately.
See kernel/diagnostics/p22-perf and debian/samba-splice in the repository.
Runtime/benchmark results: bench/results/2026-10-26-p22-perf.
This is bounded boot/integrity validation, not the historical 96-hour torture test.
