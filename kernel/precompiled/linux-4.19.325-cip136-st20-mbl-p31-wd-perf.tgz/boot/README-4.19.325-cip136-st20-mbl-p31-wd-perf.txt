Linux 4.19.325-cip136-st20-mbl-p31-wd-perf (production kernel, November 2026)
Source: CIP v4.19.325-cip136 + MBL patches 0001-0029 (kernel/patches/4.19.325-cip136).
16K pages; hung-task/soft-lockup panic recovery; PERF_EVENTS enabled.
0023-0029: no dcbz traps in DW-DMA descriptor zeroing, cached descriptor/MAL state,
preallocated LLIs, inline div_u64, EMAC TX ring overflow fix, no NAPI re-poll per RX packet.
DTB is the tested board DTB (zero local-mac-address; no personal bootargs).
Use libata.force=noncq and panic=10; Samba splice is installed separately.
Results (fixed-placement SMB bench): 81.0 / 101.2 MiB/s, free CPU on read 33 %.
